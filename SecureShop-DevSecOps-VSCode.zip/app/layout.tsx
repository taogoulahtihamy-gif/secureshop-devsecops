import type {Metadata} from "next"; import "./globals.css";
export const metadata:Metadata={title:"SecureShop DevSecOps",description:"Plateforme e-commerce moderne, sécurisée et observable.",icons:{icon:"/favicon.svg"}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="fr"><body>{children}</body></html>}
